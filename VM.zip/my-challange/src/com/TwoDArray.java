package com;

public class TwoDArray {
	
	public static void main(String[] args) {
		
		String[][] report={{"IT","5000"},{"HR","6000"}};
		
		System.out.println(report[0][0]+"->"+report[0][1]);
		System.out.println(report[1][0]+"->"+report[1][1]);
		
	}

}
