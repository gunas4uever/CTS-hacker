package com;

import com.oop.hr.HR;

public class App {

	public static void main(String[] args) {

		System.out.println("start");

		HR.manageEmployees();

		System.out.println("end..");

	}

}
