package com.vm.wheel.ceat;

import com.vm.wheel.Wheel;

public class CEATWheel implements Wheel {

	@Override
	public void rotate() {
		System.out.println("CEAT Wheel rotating...");

	}

}
