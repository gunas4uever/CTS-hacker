package com.vm.wheel;

public interface Wheel {

	void rotate();

}
