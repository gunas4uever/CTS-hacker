


var app = app || {};

new app.AllPosts().render();