package com.shop.bill;

public interface Billing {

	double getTotalPrice(String[] cart);

}