package com.shop.pm;

public class PriceMatrixImpl_v1 {

	public double getPrice(String item) {
		// get price from db or ws-call
		return 100.00;
	}

}
