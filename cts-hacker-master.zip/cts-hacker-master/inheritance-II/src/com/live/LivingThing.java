package com.live;

public class LivingThing {
	
	// common prop
	
	// common behav
	
	public void eat() {
		System.out.println("LT eat");
	}
	public void sleep() {
		System.out.println("LT sleep");
	}
	public void work() {
		System.out.println("LT work..");
	}

}
