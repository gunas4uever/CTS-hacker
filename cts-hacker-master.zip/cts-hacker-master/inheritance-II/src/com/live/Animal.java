package com.live;

public class Animal extends LivingThing{

	
}
