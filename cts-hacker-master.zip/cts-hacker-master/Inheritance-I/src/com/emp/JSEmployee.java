package com.emp;

public class JSEmployee extends Employee {

	// public int id;
	// public String name;
	// public String salary;
	public String jsSkill;

	public JSEmployee(int id) {
		super(id);
	}

}
