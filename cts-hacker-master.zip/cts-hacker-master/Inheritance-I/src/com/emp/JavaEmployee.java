package com.emp;

public class JavaEmployee extends Employee {

	// public int id;
	// public String name;
	// public String salary;
	public String javaSkill;

	public JavaEmployee(int id) {
		super(id);
	}

}
