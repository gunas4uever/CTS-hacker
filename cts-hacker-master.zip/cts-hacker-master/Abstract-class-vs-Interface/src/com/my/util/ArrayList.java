package com.my.util;

public class ArrayList extends AbstractList {

	@Override
	public void add(Object e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void add(int idx, Object e) {
		// TODO Auto-generated method stub

	}

}
