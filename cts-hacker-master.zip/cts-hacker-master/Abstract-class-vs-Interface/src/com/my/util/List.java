package com.my.util;

public interface List extends Collection {
	void add(int idx, Object e);
}
