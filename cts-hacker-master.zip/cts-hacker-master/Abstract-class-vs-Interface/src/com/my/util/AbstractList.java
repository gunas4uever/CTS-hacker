package com.my.util;

public abstract class AbstractList implements List {

	@Override
	public void clear() {
		// TODO Auto-generated method stub

	}

	@Override
	public void size() {
		// TODO Auto-generated method stub

	}

}
