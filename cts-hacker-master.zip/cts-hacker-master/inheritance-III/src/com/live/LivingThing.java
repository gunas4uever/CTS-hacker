package com.live;

public abstract class LivingThing {

	// common prop

	// common behav

	public void eat() {
		System.out.println("LT eat");
	}

	public void sleep() {
		System.out.println("LT sleep");
	}

	public abstract void work();

}
