package com.live;

public class Male extends Human {

	@Override
	public void work() {
		System.out.println("Male Human work...");
	}

}
