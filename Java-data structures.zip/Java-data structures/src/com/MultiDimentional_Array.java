package com;

public class MultiDimentional_Array {
	
	public static void main(String[] args) {
		
		
		String[][][] threeD={
				{
					{
						"A","B","C"
					},
					{
						"X","Y","Z"
					}
				},
				{
					{
						"1","2","3"
					},
					{
						"4","5","6"
					}
				}
		};
		
		
		System.out.println(threeD[0][1][2]);
		
		
	}

}
