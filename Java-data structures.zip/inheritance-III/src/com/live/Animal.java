package com.live;

public class Animal extends LivingThing {

	@Override
	public void work() {
		System.out.println("Animal Work...");
	}
}
