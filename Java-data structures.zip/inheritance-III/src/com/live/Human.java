package com.live;

public abstract class Human extends LivingThing {

	public void study() {
		System.out.println("Human study");
	}

}
