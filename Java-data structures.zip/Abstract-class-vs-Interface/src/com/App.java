package com;

import java.util.ArrayList;

public class App {

	
	public static void main(String[] args) {
		
		ArrayList<String> arrayList=new ArrayList<>();
		
	}
}
