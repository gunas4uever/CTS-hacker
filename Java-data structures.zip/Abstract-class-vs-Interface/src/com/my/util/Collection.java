package com.my.util;

public interface Collection {

	void add(Object e);

	void clear();

	void size();

}
