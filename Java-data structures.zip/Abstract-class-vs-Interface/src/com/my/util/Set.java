package com.my.util;

public interface Set extends Collection {

	void first();

	void last();

}
